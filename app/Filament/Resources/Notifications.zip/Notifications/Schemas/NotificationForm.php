<?php

namespace App\Filament\Resources\Notifications\Schemas;

use App\Enums\NotificationStatus;
use App\Enums\NotificationTargetType;
use Filament\Forms\Components\DateTimePicker;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Textarea;
use Filament\Schemas\Schema;

class NotificationForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('application_id')
                    ->relationship('application', 'name')
                    ->required(),
                TextInput::make('title')
                    ->required(),
                Textarea::make('body')
                    ->required()
                    ->columnSpanFull(),
                FileUpload::make('image')
                    ->image(),
                TextInput::make('data_payload'),
                Select::make('target_type')
                    ->options(NotificationTargetType::class)
                    ->required(),
                Textarea::make('target_value')
                    ->columnSpanFull(),
                Select::make('status')
                    ->options(NotificationStatus::class)
                    ->required(),
                DateTimePicker::make('scheduled_at'),
                DateTimePicker::make('sent_at'),
                TextInput::make('created_by')
                    ->numeric(),
            ]);
    }
}
